In this project, i have deployed a static website to AWS using S3, CloudFront, and IAM.

The files included are: 

index.html - The Index document for the website.
/img - The background image file for the website.
/vendor - Bootssrap CSS framework, Font, and JavaScript libraries needed for the website to function.
/css - CSS files for the website.

The AWS S3 bucket name is - my-chidiebere-bucket

The website URL via the cloudfront distribution domain name - https://d34qyc7xl32c7j.cloudfront.net

The website via website-endpoint - http://my-chidiebere-bucket.s3-website-us-east-1.amazonaws.com/

The the bucket object via its S3 object URL - https://my-chidiebere-bucket.s3.amazonaws.com/index.html